var x = 5, j = new Object(), myarray = ['hello', 'world'];
foo = {"abc" : 23};
y = /myregex/
var myfunc = function(){ console.log("first class function"); };
myfunc() && console.log(myarray[1]);
while(x < 23.54e-5 || x === j){
  var hex = 0xFF;
  break;
}
for(var i = 0; i < 2; i++){
  if (i < i+1)
      console.log("ok") && myarray.push("7");
}
try{ throw("chucknorrisexception");  }
catch(err){   console.log("error: " + err);    }
finally{ console.log("done"); }

function aliens(obj){
  return 5%3;
}
console.log(aliens("aliens"));
//alert("stuff");
/*
 *  block comment
 */
if (x == j || foo != new Array() || undefined !== null){  isNaN(x); }
var value = ([] == [1,2,3]);
switch(foo){
  case 'bar':
      break;
    default:
      break;
}
(function(){ var foo = 'hello world'; })();  //self executing anonymous function
this.myarray = true;
var yourNamespace = {
  foo: function() {
  },
  bar: function() {
  }
};
yourNamespace.foo();
$oldvariable = 45e+75;
